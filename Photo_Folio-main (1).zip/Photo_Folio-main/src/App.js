


import Navbar from "./Components/Navbar";
import Albumslist from "./Components/AlbumsList/Albumslist"


function App() {
  return (
    <>
    <Navbar/>
    {/* <Albumform/> */}
    <Albumslist/>
    {/* <Imageslist/> */}
    </>
  );
}

export default App;
